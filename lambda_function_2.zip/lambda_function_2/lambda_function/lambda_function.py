import json
import boto3


def read_json(object, key):
    print(object)
    print(key)
    y = json.loads(object)
    print(y)
    keys = key.split('/')
    print (keys)
    for k in keys:
        # y = y.parsedJsonObject(k)
        y = y[k]
        print (y)